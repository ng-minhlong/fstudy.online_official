=== WP Dark Mode Ultimate ===
Contributors: wppool
Tags: dark, dark mode, night mode, gutenberg blocks, dark theme
Requires at least: 4.6
Tested up to: 6.6
Requires PHP: 5.6
Stable tag: 4.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Dark Mode automatically enables a stunning dark mode of your website based on user's operating system. Supports macOS, Windows, Android & iOS.

== Description ==

Use WP Dark Mode to enable a stunning dark mode theme for your WordPress website.

WP Dark Mode works automatically without going into any complicated settings.

Just activate the plugin and your users will experience a dark mode version of your website as per their preferred operating system preference.


https://www.youtube.com/watch?v=L6EmXREa6OA


Works across all operating systems including Android, iOS, macOS. No settings needed. The plugin intelligently detects device preferenc and dynamically delivers a hand crafted, expert designed dark mode experience for your readers.

Just activate dark mode on your device, and browse the website to experience a magically transformed dark mode of your website.

WP Dark Mode supports all major operating systems including iOS, Android, macOS or Windows 10.

== Changelog ==

= 4.0.0 =
* Revamped