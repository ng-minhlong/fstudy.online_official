<?php
/**
 * Draft courses
 *
 * @package Tutor\Templates
 * @subpackage Dashboard\My_Courses
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

$active_tab = 'my-courses/draft-courses';
require dirname( __DIR__ ) . DIRECTORY_SEPARATOR . 'my-courses.php';

