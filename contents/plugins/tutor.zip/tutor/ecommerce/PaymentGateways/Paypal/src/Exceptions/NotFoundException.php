<?php
namespace Ollyo\PaymentHub\Exceptions;


use RuntimeException;
use Throwable;

final class NotFoundException extends RuntimeException implements Throwable
{
}